<?php
require_once('conexao.php');

//Condicional utilizando isset para verificar se a variável não é null
if (isset($_GET['excluir'])) {
    $id = filter_input(INPUT_GET, 'excluir', FILTER_SANITIZE_NUMBER_INT);

    // verifica se o ID existe para realizar a exclusão
    if ($id) {
        $con->exec('DELETE FROM alunos WHERE id=' . $id);
    }
    // após validar o ID do aluno, retorna para o index.php
    header('location: index.php');
    exit;
}

//busca todas as linhas da tabela "alunos" e traz como resultado
$results = $con->query('select * from alunos')->fetchAll();


include_once('Layout/_header.php');
?>

<div class="change" id="change">
    <button type="button" class="btn btn-dark text-center btn-custom ">
    Dark mode
    </button>
</div>
<!--Div para inserir o card e alinhamento do texto através do bootstrap -->
<div class="card mt-4">
    <div class="card-header d-flex justify-content-between align-items-center">
        <img src="img/logo-pentagono.png" class="rounded float-left" alt="Colégio Pentágono"/> 
        <h5>Alunos </h5>
        <a class="btn btn-outline-success" href="criar.php">Adicionar</a>
    </div>
    <div class="card-body">
        <!--Table utilizando tags T(head, body e foot) para criar células na tabela de acordo com as informações que serão inseridas posteriormente -->
        <table class="table table-stripped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome do aluno</th>
                    <th>Email</th>
                    <th>Telefone</th>
                    <th>Nome do responsável</th>
                    <th>Ação</th>
                </tr>
                </t>
            </thead>
            <tbody>
                <!-- Foreach para rodar todas as colunas da tabela "alunos" e imprimir na tela o resultado-->
                <?php foreach ($results as $item) : ?>
                    <tr>
                        <td class="trocaCor">
                            <?php echo $item['Id']; ?>
                        </td>
                        <td>
                            <?php echo $item['nome']; ?>
                        </td>
                        <td>
                            <?php echo $item['email']; ?>
                        </td>
                        <td>
                            <?php echo $item['telefone']; ?>
                        </td>
                        <td>
                            <?php echo $item['nome_resp']; ?>
                        </td>

                        <td>
                            <!--Botão primary em azul para Editar o dado -->
                            <a class="btn btn-sm btn-primary" href="criar.php?id=<?= $item['Id'] ?>">Editar</a>
                            <!--Botão "danger" com a função para Excluir o dado -->
                            <button class="btn btn-sm btn-danger" onclick="excluir(<?= $item['Id'] ?>)">Excluir</button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!--Função em JS para excluir aluno no click do botão "danger" -->
<script>
    function excluir(id) {
        if (confirm("Deseja excluir o registro deste aluno?")) {
            window.location.href = "index.php?excluir=" + id;
        }
    }
</script>

<!-- Função teste JQuery -->
<script>
    jQuery('.trocaCor').css({
        'color': '#C800FE'
    })

    $.ajax({
        statusCode: {
            404: function() {
                alert("page not found");
            }
        }
    });
</script>

<script>
    document.getElementById('change').addEventListener('click', () => {
        if (document.documentElement.getAttribute('data-bs-theme') == 'dark') {
            document.documentElement.setAttribute('data-bs-theme', 'light')
        } else {
            document.documentElement.setAttribute('data-bs-theme', 'dark')
        }
    });
</script>

<!-- JS teste para alterar botão do dark mode
        <script>
            var modoBotaoLista = ['Claro', 'Escuro'];
            var Index = 0;
            var modo = document.querySelector(".modoBotao");
            var botao = document.querySelector(".btn-custom");
            botao.addEventListener("click", function() {

                if (index + 1 == modoBotaoLista.length) {
                    index = 0;
                } else {
                    index = index + 1;
                }
                modo.textContent = modoBotaoLista[index]
                console.log(modoBotaoLista);
            })
        </script>
-->

<?php include_once('Layout/_footer.php'); ?>