<?php
$con = new PDO ('mysql:host=localhost;dbname=mycrud','felipebeltran','felipe123');
?>