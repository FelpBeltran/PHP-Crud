<?php 
require_once('conexao.php');

$id = 0;
$nome = '';
$email = '';
$telefone = '';
$nome_resp = '';

if (isset($_GET['id'])) {
    $id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);
    if (!$id) {
        header('Location: index.php');
        exit;
    }
    $stmt = $con->prepare('SELECT * FROM alunos WHERE id = :id');
    $stmt->bindValue(':id', $id);
    $stmt->execute();
    $result = $stmt->fetch();

    if (!$result) {
        header('Location: index.php');
        exit;
    }

    $nome = $result['nome'];
    $email = $result['email'];
    $telefone = $result['telefone'];
    $nome_resp = $result['nome_resp'];
}

if (isset($_POST['id'])) {
    $id = filter_input(INPUT_POST, 'id', FILTER_SANITIZE_NUMBER_INT);
    $nome = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $telefone = filter_input(INPUT_POST, 'telefone', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $nome_resp = filter_input(INPUT_POST, 'nome_resp', FILTER_SANITIZE_FULL_SPECIAL_CHARS);

    if ($id) {
        $stmt = $con->prepare("UPDATE alunos SET nome = :nome, email = :email, telefone = :telefone, nome_resp = :nome_resp WHERE id = :id");
        $stmt->bindValue(':id', $id);
    } else {
        $stmt = $con->prepare("INSERT INTO alunos (nome, email, telefone, nome_resp) VALUES (:nome, :email, :telefone, :nome_resp)");
    }
    $stmt->bindValue(':nome', $nome);
    $stmt->bindValue(':email', $email);
    $stmt->bindValue(':telefone', $telefone);
    $stmt->bindValue(':nome_resp', $nome_resp);
    $stmt->execute();

    header("Location: index.php");
    exit;
}

include_once('Layout/_header.php');
?>

<div class="card mt-4">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5><?= $id ? 'Editar aluno ' . $id : 'Adicionar aluno' ?></h5>
    </div>
    <form method="post" autocomplete="off">
        <div class="card-body">
            <input type="hidden" name="id" value="<?= $id ?>"/>
            <div class="form-group">
                <label for="nome">Nome</label>
                <input type="text" class="form-control" id="nome" name="nome" value="<?= $nome ?>" required/>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" class="form-control" id="email" name="email" value="<?= $email ?>" required/>
            </div>
            <div class="form-group">
                <label for="telefone">Telefone</label>
                <input type="text" class="form-control" id="telefone" name="telefone" value="<?= $telefone ?>" required/>
            </div>
            <div class="form-group">
                <label for="nome_resp">Nome do responsável</label>
                <input type="text" class="form-control" id="nome_resp" name="nome_resp" value="<?= $nome_resp ?>" required/>
            </div>
        </div>
        <div class="card-footer">
            <button type="submit" class="btn btn-success">Salvar</button>
            <a class="btn btn-primary" href="index.php">Voltar</a>
        </div>
    </form>
</div>

<?php include_once('Layout/_footer.php'); ?>
